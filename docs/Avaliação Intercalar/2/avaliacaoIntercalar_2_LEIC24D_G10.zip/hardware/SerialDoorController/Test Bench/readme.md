Package for Serial LCD Controller module test bench
