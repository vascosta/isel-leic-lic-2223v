Package for Sistema de Controlo de Acessos module pins
